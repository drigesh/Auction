package com.oyo.auctionplatform.controller;

import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.pojo.AuctionWithUserDetails;
import com.oyo.auctionplatform.services.AuctionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
public class AuctionController {

    @Autowired
    private AuctionService auctionService;


    //get all auctions
    @GetMapping("/auction")
    public List<Auction> getAllAuctions() {
        return auctionService.getAllAuctions();
    }

    //Getting Auctions by auctionId
    @GetMapping("/auction/{auctionId}")
    public Auction getAuctionByAuctionId(@PathVariable(value = "auctionId") Integer auctionId)
            throws ResourceNotFoundException {
        return auctionService.getAuctionByAuctionId(auctionId);
    }

    //Creating a new auction
    //try catch required for handling exception
    @PostMapping("/auction")
    public Auction createAuction(@Valid @RequestBody AuctionWithUserDetails auctionWithUserDetails)
            throws ResourceNotFoundException {
        return auctionService.createAuction(auctionWithUserDetails);
    }


    //updating an existing auction
    @PostMapping("/auction/{auctionId}")
    public Auction updateAuction(@PathVariable(value = "auctionId") Integer auctionId,
                                 @Valid @RequestBody AuctionWithUserDetails auctionWithUserDetails)
            throws ResourceNotFoundException {
        return auctionService.updateAuction(auctionId, auctionWithUserDetails);
    }

    //Delete a particular auction
    @DeleteMapping("/auction/{auctionId}")
    public Map<String, Boolean> deleteAuction(@PathVariable(value = "auctionId") Integer auctionId,
                                              @RequestBody AuctionWithUserDetails auctionWithUserDetails)
            throws ResourceNotFoundException {
        return auctionService.deleteAuction(auctionId, auctionWithUserDetails);
    }

    //Get all active auctions
    @GetMapping("/active-auctions")
    public List<Auction> getActiveAuctions() {
        List<Auction> auctions = auctionService.activeAuctions();
        return auctions;
    }

}
