package com.oyo.auctionplatform.pojo;

import com.oyo.auctionplatform.entity.Inventory;
import com.oyo.auctionplatform.entity.User;

public class InventoryWithUserDetails {


    private Inventory inventory;

    //    private String emailId,password;
    private User user;

    public Inventory getInventory() {
        return inventory;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

//    public String getEmailId() {
//        return emailId;
//    }
//
//    public void setEmailId(String emailId) {
//        this.emailId = emailId;
//    }
//
//    public String getPassword() {
//        return password;
//    }
//
//    public void setPassword(String password) {
//        this.password = password;
//    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
