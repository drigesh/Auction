package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.*;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.InventoryManager;
import com.oyo.auctionplatform.pojo.InventoryWithUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.lang.module.ResolutionException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class InventoryService {


    @Autowired
    private InventoryManager inventoryManager;
    @Autowired
    private UserService userService;

    @Autowired
    private WalletService walletService;

    @Autowired
    private AuctionService auctionService;

    @Autowired
    private BidService bidService;

//todo vinay slf4j


    public List<Inventory> getAllInventories() {
        List<Inventory> inventories = inventoryManager.getAllInventory();
//        System.out.println(inventories);
        return inventories;
    }


    public Inventory getInventoryById(@Valid Integer Id) throws ResourceNotFoundException {

        Inventory inventory = inventoryManager.getInventoryById(Id)
                .orElseThrow(() -> new ResourceNotFoundException("inventory not found for this id :: " + Id));
        return inventory;
    }


    // add inventory

    public Inventory createInventory(@Valid InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {

        User user = userService.validateUser(inventoryWithUserDetails.getUser(), 2);

        Inventory inventory = inventoryWithUserDetails.getInventory();
        inventory.setUserId(user.getUserId());
        return inventoryManager.saveInventory(inventory);
    }


    // update inventory

    public Inventory updateInventory(Integer Id, @Valid InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {

        userService.validateUser(inventoryWithUserDetails.getUser(), 2);

        Inventory inventoryDetails = inventoryWithUserDetails.getInventory();

        Inventory inventory = inventoryManager.getInventoryById(Id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory not found for the ID :: " + Id));

        inventory.getInventoryMetaData().setAddress(inventoryDetails.getInventoryMetaData().getAddress());
        inventory.setArrivalDate(inventoryDetails.getArrivalDate());
        inventory.setCommission(inventoryDetails.getCommission());
        inventory.getInventoryMetaData().setCountry(inventoryDetails.getInventoryMetaData().getCountry());
        inventory.setInventoryId(inventoryDetails.getInventoryId());
        inventory.setInventoryName(inventoryDetails.getInventoryName());
        inventory.getInventoryMetaData().setPhone(inventoryDetails.getInventoryMetaData().getPhone());
        inventory.setDepartureDate(inventoryDetails.getDepartureDate());
        inventory.getInventoryMetaData().setState(inventoryDetails.getInventoryMetaData().getState());
        inventory.getInventoryMetaData().setPincode(inventoryDetails.getInventoryMetaData().getPincode());

        final Inventory updatedInventory = inventoryManager.saveInventory(inventory);
        return updatedInventory;

    }


    public Map<String, Boolean> deleteInventory(Integer Id, InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {

        userService.validateUser(inventoryWithUserDetails.getUser(), 2);

        Inventory inventory = inventoryManager.getInventoryById(Id)
                .orElseThrow(() -> new ResourceNotFoundException("Inventory doesn't exist :: " + Id));
        String auction = auctionService.getAuctionByInventoryId(inventory.getInventoryId()).getStatus();
        Map<String, Boolean> response = new HashMap<>();
        if (auction == "active") {
            response.put("not able to delete as this inventory is currently in auction", Boolean.FALSE);
            return response;
        }
        inventoryManager.deleteInventory(inventory);

        response.put("deleted", Boolean.TRUE);
        return response;

    }


    public User getWinnerOfInventory(Integer inventoryId) throws ResourceNotFoundException {
        Bid highestBid = bidService.getHighestBid(inventoryId);
        User winnerUser = userService.getUserById(highestBid.getUserId());
        return winnerUser;
    }


    public User ownerOfInventory(Integer inventoryId) throws ResourceNotFoundException {
        //Auction currentAuction = auctionManager.findByAuctionId(auctionId).orElseThrow(() -> new ResourceNotFoundException("auction id is invalid"));
        Inventory inv = inventoryManager.getInventoryById(inventoryId).orElseThrow(() -> new ResolutionException("Inventory not found"));
        User owner = userService.getUserById(inv.getUserId());
        return owner;
    }


    public Auction findAuctionByInventoryId(Integer inventoryId) throws ResourceNotFoundException {
        Auction currentAuction = auctionService.getAuctionByInventoryId(inventoryId);
        return currentAuction;
    }

    public User getWinnerAndSettleAmount(Integer inventoryId) throws ResourceNotFoundException {
        User winnerOfInventory = this.getWinnerOfInventory(inventoryId);
        User ownerOfInventory = this.ownerOfInventory(inventoryId);
        Auction currentAuction = this.findAuctionByInventoryId(inventoryId);
        Bid highestBid = bidService.getHighestBid(inventoryId);
        if (highestBid != null) {
            Wallet winnerWallet = walletService.getWalletByUserId(winnerOfInventory.getUserId());
            Wallet ownerWallet = walletService.getWalletByUserId(ownerOfInventory.getUserId());
            winnerWallet.setBlockedAmount(winnerWallet.getBlockedAmount() - highestBid.getBidPrice());
            ownerWallet.setTotalAmount(ownerWallet.getTotalAmount() + highestBid.getBidPrice());
            winnerWallet.setTotalAmount(winnerWallet.getTotalAmount() - highestBid.getBidPrice());
            walletService.saveWallet(ownerWallet);
            walletService.saveWallet(winnerWallet);
        }
        currentAuction.setStatus("Settled");

        auctionService.saveAuction(currentAuction);
        return winnerOfInventory;
    }

}
