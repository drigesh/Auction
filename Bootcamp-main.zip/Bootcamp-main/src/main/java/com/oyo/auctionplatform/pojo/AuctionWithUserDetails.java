package com.oyo.auctionplatform.pojo;

import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.entity.User;

public class AuctionWithUserDetails {


    private Auction auction;

    private User user;

    public Auction getAuction() {
        return auction;
    }

    public void setAuction(Auction auction) {
        this.auction = auction;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
