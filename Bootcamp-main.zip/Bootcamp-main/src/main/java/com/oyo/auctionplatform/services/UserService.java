package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.entity.Wallet;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.UserManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserService {

    BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
    @Autowired
    private UserManager userManager;

    @Autowired
    private WalletService walletService;

    // get all users
    public List<User> getAllUsers() {
        return userManager.getAllUsers();
    }



    // get user by id
    public User getUserById(Integer userId)
            throws ResourceNotFoundException {
        User user = userManager.getUserById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("user not found for this id :: " + userId));
        return user;
    }



    // post user
    public String createUser(User user)
    throws ResourceNotFoundException{
        User userToStore = user;

        userToStore.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));

        walletService.createWallet(user);
        return "User created successfully!";
    }



    public User updateUser(Integer userId, User userDetails)
            throws ResourceNotFoundException {
        User user = userManager.getUserById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found for the ID :: " + userId));

        if (userDetails.getName() != null) user.setName(userDetails.getName());
        if (userDetails.getPassword() != null) user.setPassword(userDetails.getPassword());
        if (userDetails.getContact() != null) user.setContact(userDetails.getContact());
        if (userDetails.getAddress() != null) user.setAddress(userDetails.getAddress());
        if (userDetails.getEmail() != null) user.setEmail(userDetails.getEmail());
        if (userDetails.getType() != null) user.setType(userDetails.getType());

        return userManager.saveUser(user);
    }


    // delete user
    public String deleteUser(Integer userId)
            throws ResourceNotFoundException {
        User user = userManager.getUserById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User doesn't exist :: " + userId));

        userManager.deleteUser(user);
        return "User deleted successfully!";

    }


    //login user
    public String loginUser(User userDetails) {

        User user = userManager.getUserByEmail(userDetails.getEmail());

        if (user == null) return "User does not exist, register yourself!";
        if (bCryptPasswordEncoder.matches(userDetails.getPassword(), user.getPassword())) {
            return "User login successful!";
        }
        return "Credentials do not match";
    }


    // validate user
    public User validateUser(User user, Integer type)
            throws ResourceNotFoundException {

        String email = user.getEmail();
        String password = user.getPassword();


        User userFound = userManager.getUserByEmail(email);
        if (userFound == null) {
            throw new ResourceNotFoundException("Not a valid user!");
        }
        if (!bCryptPasswordEncoder.matches(password, userFound.getPassword())) {
            throw new ResourceNotFoundException("Password is not correct");
        }
        if (userFound.getType() != type) {
            throw new ResourceNotFoundException("You are not authorised to perform the operation.");
        }
        return userFound;
    }


}