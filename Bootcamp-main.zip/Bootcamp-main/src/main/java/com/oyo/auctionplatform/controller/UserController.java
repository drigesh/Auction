package com.oyo.auctionplatform.controller;

import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {

    @Autowired
    private UserService userService;


    // get all users
    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }



    // get user by id
    @GetMapping("/user/{userId}")
    public User getUserById(@PathVariable(value = "userId") Integer userId)
            throws ResourceNotFoundException {
        return userService.getUserById(userId);
    }


    // create user
    @PostMapping("/user")
    public String createUser(@Valid @RequestBody User user)
            throws ResourceNotFoundException {
        String response = userService.createUser(user);
        return response;
    }


    //update user
    @PatchMapping("/user/{userId}")
    public User updateUser(@PathVariable(value = "userId") Integer userId, @Valid @RequestBody User userDetails)
            throws ResourceNotFoundException {
        return userService.updateUser(userId, userDetails);
    }


    // delete user
    @DeleteMapping("/user/{userId}")
    public String deleteUser(@PathVariable(value = "userId") Integer userId)
            throws ResourceNotFoundException {
        return userService.deleteUser(userId);

    }


    // user login
    @PostMapping("/auth")
    public String loginUser(@Valid @RequestBody User userDetails)
            throws ResourceNotFoundException {
        return userService.loginUser(userDetails);
    }

}