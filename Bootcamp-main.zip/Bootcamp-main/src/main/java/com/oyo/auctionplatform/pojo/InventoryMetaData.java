package com.oyo.auctionplatform.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
//@Getter
//@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InventoryMetaData {


    private String title;
    private String iconUrl;
    private String tncUrl;
    private String hash;

    private String address;
    private String state;
    private String country;
    private String phone;

    private Integer pincode;


}
