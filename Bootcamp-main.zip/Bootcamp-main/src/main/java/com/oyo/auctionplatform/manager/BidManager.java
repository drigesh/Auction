package com.oyo.auctionplatform.manager;

import com.oyo.auctionplatform.entity.Bid;
import com.oyo.auctionplatform.repository.BidRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("BidManager")
public class BidManager {

    @Autowired
    private BidRepo bidRepo;

    public ArrayList<Bid> getBidsByInventoryId(Integer inventoryId) {
        return bidRepo.findByInventoryId(inventoryId);
    }

    public List<Bid> getBidsByUserId(Integer userId) {
        return bidRepo.findByUserId(userId);
    }

    public Bid getFirstByInventoryIdOrderByBidPriceDesc(Integer inventoryId) {
        return bidRepo.findFirstByInventoryIdOrderByBidPriceDesc(inventoryId);
    }

    public Bid saveBid(Bid bid) {
        return bidRepo.save(bid);
    }
}
