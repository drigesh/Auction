package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.entity.Bid;
import com.oyo.auctionplatform.entity.Inventory;
import com.oyo.auctionplatform.entity.Wallet;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.BidManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class BidService {

    @Autowired
    private BidManager bidManager;

    @Autowired
    private AuctionService auctionService;

    @Autowired
    private InventoryService inventoryService;

    @Autowired
    private WalletService walletService;

    public Bid createBid(@Valid Bid bid) throws ResourceNotFoundException {

        Integer inventoryId = bid.getInventoryId();
        Inventory inventoryBidden = inventoryService.getInventoryById(inventoryId);
        Auction auction = auctionService.getAuctionByInventoryId(inventoryId);
        //date should be there instead  of status
        if (!auction.getStatus().equals("active")) {
            log.error("This Auction is over now" + auction.getAuctionId());
            throw new ResourceNotFoundException("this Auction is over now");
        }

        if (auction.getStrategy() == 1) {
            //getting any current highest bid
            Bid currentHighestBid = bidManager.getFirstByInventoryIdOrderByBidPriceDesc(inventoryId);
            float minimumBidPrice = 0.0F;
            //getting wallet of current bidder
            Wallet wallet = walletService.getWalletByUserId(bid.getUserId());
            //checking for the sufficient amount
            if ((wallet.getTotalAmount() - wallet.getBlockedAmount()) < bid.getBidPrice()) {
                log.error("Not enough balance in your Wallet");
                throw new ResourceNotFoundException("not enough balance in your wallet");
            }
            //if there is no bid previously then the minimum bid price would be the base price of auction
            if (currentHighestBid == null)
                minimumBidPrice = inventoryBidden.getBasePrice();
            else {
                //else previous bid + minimum bid raise
                minimumBidPrice += auction.getMinimumBidRaise();
            }
            //checking if bid is in suggested limits
            if (minimumBidPrice <= bid.getBidPrice()) {
                //blocking amount in current bidder account
                wallet.setBlockedAmount(wallet.getBlockedAmount() + bid.getBidPrice());
                if (currentHighestBid != null) {
                    Wallet prevHighestBidderWallet = walletService.getWalletByUserId(currentHighestBid.getUserId());
                    prevHighestBidderWallet.setBlockedAmount(prevHighestBidderWallet.getBlockedAmount() - currentHighestBid.getBidPrice());
                }
                return bidManager.saveBid(bid);
            } else {
                log.error("Bid not in suggested limit");
                throw new ResourceNotFoundException("Bid not in suggested limit");
            }
        } else {
            log.error("Wrong strategy");
            throw new ResourceNotFoundException("Strategy not found");
        }
    }


    public Bid getHighestBid(Integer inventoryId) {
        return bidManager.getFirstByInventoryIdOrderByBidPriceDesc(inventoryId);
    }

    public ArrayList<Bid> getAllBidsForInventory(Integer inventoryId) {
        return bidManager.getBidsByInventoryId(inventoryId);
    }

    public List<Bid> getAllBidsForUser(Integer userId) {
        return bidManager.getBidsByUserId(userId);
    }
}