package com.oyo.auctionplatform.controller;

import com.oyo.auctionplatform.entity.Wallet;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.services.WalletService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
//import java.util.HashMap;
//import java.util.Map;

@RestController
public class WalletController {
    @Autowired
    private WalletService walletService;



    //Getting  wallet by userId
    @GetMapping("/wallet/{userId}")
    public Wallet getWalletById(@PathVariable(value = "userId") Integer userId)
            throws ResourceNotFoundException {
        return walletService.getWalletByUserId(userId);
    }


    //Updating wallet by userId

//    @PutMapping("/wallet/{userId}")
//    public Wallet updateWallet(@PathVariable(value = "userId") Integer userId,
//                               @Valid @RequestBody Wallet walletDetails)
//            throws ResourceNotFoundException {
//        return walletService.updateWallet(userId, walletDetails);
//    }


    //Recharge Wallet

    @PutMapping("/wallet/{userId}/recharge")
    public Wallet rechargeWallet(@PathVariable(value = "userId") Integer userId,
                                 @Valid @RequestBody float rechargeAmount)
            throws ResourceNotFoundException {
        return walletService.rechargeWallet(userId, rechargeAmount);
    }

    //Redeem Money

    @PutMapping("/wallet/{userId}/redeem")
    public Wallet redeemMoney(@PathVariable(value = "userId") Integer userId,
                                              @Valid @RequestBody float redeemAmount)
            throws ResourceNotFoundException {
        return walletService.redeemMoney(userId, redeemAmount);
    }


}