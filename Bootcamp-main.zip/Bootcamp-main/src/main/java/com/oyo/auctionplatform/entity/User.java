package com.oyo.auctionplatform.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {


    @Column(nullable = false)
    private String name;

    @Id
    @SequenceGenerator(
            name = "user_sequence",
            sequenceName = "user_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "user_sequence"
    )
    @Column(nullable = false)
    private Integer userId;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column()
    private String contact;

    @Column()
    private String address;

    @Column(nullable = false, columnDefinition = "")
    private Integer type;

    @JsonManagedReference
    @OneToOne(cascade = CascadeType.REMOVE, mappedBy = "user",fetch = FetchType.LAZY)
    private Wallet wallet;

    public User(String name, Integer userId, String email, String password, String contact, String address, Integer type) {
        this.name = name;
        this.userId = userId;
        this.email = email;
        this.password = password;
        this.contact = contact;
        this.address = address;
        this.type = type;
    }
}