package com.oyo.auctionplatform.manager;

import com.oyo.auctionplatform.entity.Wallet;
import com.oyo.auctionplatform.repository.WalletRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("WalletManager")
public class WalletManager {

    @Autowired
    private WalletRepo walletRepo;

    public Wallet saveWallet(Wallet wallet) {
        return walletRepo.save(wallet);
    }

    public Optional<Wallet> getWalletById(Integer walletId) {
        return walletRepo.findById(walletId);
    }

}
