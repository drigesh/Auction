package com.oyo.auctionplatform.entity;

import com.oyo.auctionplatform.pojo.AuctionMetaData;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Auction")
@AllArgsConstructor
@NoArgsConstructor
@Data
@TypeDefs({
        @TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
})
public class Auction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer auctionId;

    @Column(name = "inventoryId", nullable = false)
    private Integer inventoryId;

    @Column(name = "status", nullable = false)
    private String status;


    @Column(name = "startDate", nullable = false)
    private Date startDate;

    @Column(name = "endDate", nullable = false)
    private Date endDate;

    @Column(name = "minimumBidRaise", nullable = false)
    private float minimumBidRaise;

    @Column(name = "upperCap", nullable = false)
    private float upperCap;

    @Column(name = "strategy", nullable = false)
    private Integer strategy;

    @OneToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "inventoryId", referencedColumnName = "id", updatable = false, insertable = false)
    private Inventory inv;

    @Type(type = "jsonb")
    @Column(name = "auctionMetaData", columnDefinition = "jsonb")
    private AuctionMetaData auctionMetaData;


}
