package com.oyo.auctionplatform.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Date;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Bid")
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bidId;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "inventoryId", nullable = false)
    private Integer inventoryId;

    @Column(name = "bidPrice", nullable = false)
    private float bidPrice;

    @Column(name = "bidDate", nullable = false)
    private Date bidDate;

    @ManyToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "userId", referencedColumnName = "userId", insertable = false, updatable = false)
    private User user;

    @ManyToOne(cascade = CascadeType.REMOVE)
    @JoinColumn(name = "inventoryId", referencedColumnName = "id", insertable = false, updatable = false)
    private Inventory inventory;

}














