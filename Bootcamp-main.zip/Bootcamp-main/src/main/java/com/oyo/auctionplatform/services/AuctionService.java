package com.oyo.auctionplatform.services;


import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.AuctionManager;
import com.oyo.auctionplatform.pojo.AuctionWithUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.module.ResolutionException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AuctionService {

    @Autowired
    private AuctionManager auctionManager;
    @Autowired
    private BidService bidService;

    @Autowired
    private UserService userService;

    @Autowired
    private InventoryService inventoryService;

    @Autowired
    private WalletService walletService;

    public List<Auction> getAllAuctions() {
        return auctionManager.getAllAuctions();
    }

    public List<Auction> activeAuctions() {

        Date now = new Date();
        List<Auction> auctions = auctionManager.findByStartDateBeforeAndEndDateAfterAndStatus(now, now, "active");

        return auctions;
    }

    //
//    public User getWinnerOfAuction(Integer auctionId) throws ResourceNotFoundException {
//        Bid highestBid = bidService.getHighestBid(auctionId);
//        User winnerUser = userService.getUserById(highestBid.getUserId());
//        return winnerUser;
//    }
//
//    public User ownerOfInventory(Integer auctionId) throws ResourceNotFoundException {
//        Auction currentAuction = auctionManager.findByAuctionId(auctionId).orElseThrow(() -> new ResourceNotFoundException("auction id is invalid"));
//        Inventory inv = inventoryService.getInventoryById(currentAuction.getInventoryId());
//        User owner = userService.getUserById(inv.getUserId());
//        return owner;
//    }
//
    public Auction getAuctionByAuctionId(Integer auctionId) {
        Auction currentAuction = auctionManager.findByAuctionId(auctionId).orElseThrow(() -> new ResolutionException("auction id is not found"));
        return currentAuction;
    }

    public Auction getAuctionByInventoryId(Integer inventoryId) throws ResourceNotFoundException {
        Auction currentAuction = auctionManager.findByInventoryId(inventoryId);
        return currentAuction;
    }

    public Auction saveAuction(Auction auction) {
        return auctionManager.saveAuction(auction);
    }

//
//    public User getWinnerAndSettleAmount(Integer auctionId) throws ResourceNotFoundException {
//        User winnerOfAuction = this.getWinnerOfAuction(auctionId);
//        User ownerOfInventory = this.ownerOfInventory(auctionId);
//        Auction currentAuction = this.getAuctionByAuctionId(auctionId);
//        Wallet winnerWallet = walletService.getWalletByUserId(winnerOfAuction.getUserId());
//        Wallet ownerWallet = walletService.getWalletByUserId(ownerOfInventory.getUserId());
//        Bid highestBid = bidService.getHighestBid(auctionId);
//        winnerWallet.setBlockedAmount(winnerWallet.getBlockedAmount() - highestBid.getBidPrice());
//        ownerWallet.setTotalAmount(ownerWallet.getTotalAmount() + highestBid.getBidPrice());
//        winnerWallet.setTotalAmount(winnerWallet.getTotalAmount() - highestBid.getBidPrice());
//        currentAuction.setStatus("Settled");
//        walletService.saveWallet(ownerWallet);
//        walletService.saveWallet(winnerWallet);
//        auctionManager.saveAuction(currentAuction);
//        return winnerOfAuction;
//    }


    public Auction updateAuction(Integer auctionId, AuctionWithUserDetails auctionWithUserDetails)
            throws ResourceNotFoundException {

        User user = userService.validateUser(auctionWithUserDetails.getUser(), 3);

        Auction auctionDetails = auctionWithUserDetails.getAuction();

        Auction auction = auctionManager.findByAuctionId(auctionId)
                .orElseThrow(() -> new ResourceNotFoundException("Auction not found for the ID :: " + auctionId));

        auctionDetails.setAuctionId(auction.getAuctionId());

        final Auction updatedAuction = auctionManager.saveAuction(auctionDetails);
        return updatedAuction;
    }


    public Map<String, Boolean> deleteAuction(Integer auctionId, AuctionWithUserDetails auctionWithUserDetails)
            throws ResourceNotFoundException {

        User user = userService.validateUser(auctionWithUserDetails.getUser(), 3);

        Auction auction = auctionManager.findByAuctionId(auctionId)
                .orElseThrow(() -> new ResourceNotFoundException("Auction doesn't exist :: " + auctionId));

        auctionManager.deleteAuction(auction);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return response;

    }


    public Auction createAuction(AuctionWithUserDetails auctionWithUserDetails) throws ResourceNotFoundException {

        userService.validateUser(auctionWithUserDetails.getUser(), 3);

        return auctionManager.saveAuction(auctionWithUserDetails.getAuction());
    }


}
