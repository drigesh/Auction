package com.oyo.auctionplatform.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "wallet")
public class Wallet {

    @Id
    @Column(name = "walletId")
    @SequenceGenerator(
            name = "wallet_sequence",
            sequenceName = "wallet_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "wallet_sequence"
    )
    private Integer walletId;


    @Column(name = "totalAmount")
    private float totalAmount;

    @Column(name = "blockedAmount")
    private float blockedAmount;

    @JsonBackReference
    @OneToOne(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    @JoinColumn(
            name = "userId",
            referencedColumnName = "userId"
    )
    private User user;


    public Wallet(float totalAmount, float blockedAmount, User user) {
        this.totalAmount = totalAmount;
        this.blockedAmount = blockedAmount;
        this.user = user;
    }
}
