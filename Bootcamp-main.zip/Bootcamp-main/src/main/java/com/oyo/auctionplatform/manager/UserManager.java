package com.oyo.auctionplatform.manager;

import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("UserManager")
public class UserManager {

    @Autowired
    private UserRepo userRepo;

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    public Optional<User> getUserById(Integer userId) {
        return userRepo.findById(userId);
    }

    public User saveUser(User user) {
        return userRepo.save(user);
    }

    public void deleteUser(User user) {
        userRepo.delete(user);
    }

    public User getUserByEmail(String email) {
        return userRepo.findByEmail(email);
    }

}
