package com.oyo.auctionplatform.repository;

import com.oyo.auctionplatform.entity.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface WalletRepo extends JpaRepository<Wallet, Integer> {
    Wallet findWalletByWalletId(Integer walletId);
}
