package com.oyo.auctionplatform.manager;

import com.oyo.auctionplatform.entity.Inventory;
import com.oyo.auctionplatform.repository.InventoryRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("InventoryManager")
public class InventoryManager {

    @Autowired
    private InventoryRepo inventoryRepo;

    public List<Inventory> getAllInventory() {
        return inventoryRepo.findAll();
    }

    public Optional<Inventory> getInventoryById(Integer Id) {
        return inventoryRepo.findById(Id);
    }

    public Inventory saveInventory(Inventory inventory) {
        return inventoryRepo.save(inventory);
    }

    public void deleteInventory(Inventory inventory) {
        inventoryRepo.delete(inventory);
    }
}
