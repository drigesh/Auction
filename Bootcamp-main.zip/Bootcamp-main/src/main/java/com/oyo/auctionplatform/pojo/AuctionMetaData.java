package com.oyo.auctionplatform.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuctionMetaData {

    private String title;
    private String iconUrl;
    private String tncUrl;
    private String hash;

}
