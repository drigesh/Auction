package com.oyo.auctionplatform.controller;


import com.oyo.auctionplatform.entity.Bid;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.services.BidService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

//place bid at controller level
@RestController
@RequestMapping(value = "/bid")
public class BidController {

    @Autowired
    private BidService bidService;


    @GetMapping("/{id}")
    public List<Bid> getAllBidsForInventory(@PathVariable(value = "id") Integer inventoryId) {
        return bidService.getAllBidsForInventory(inventoryId);
    }

    //creating a bid
    @PostMapping("/place")
    public Bid createBid(@Valid @RequestBody Bid bid) throws ResourceNotFoundException {
        Bid addedBid = bidService.createBid(bid);
        return addedBid;
    }

    //get highest bid for inventory
    //try catch
    @GetMapping("/highest/{id}")
    public Bid getHighestBidForInventory(@PathVariable(value = "id") Integer inventoryId) {
        return bidService.getHighestBid(inventoryId);
    }


    @GetMapping("/user/{userId}")
    public List<Bid> getAllBidsForUser(@PathVariable(value = "userId") Integer userId) {
        return bidService.getAllBidsForUser(userId);
    }

}
