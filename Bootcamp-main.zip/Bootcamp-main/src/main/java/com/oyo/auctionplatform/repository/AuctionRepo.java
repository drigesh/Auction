package com.oyo.auctionplatform.repository;

import com.oyo.auctionplatform.entity.Auction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface AuctionRepo extends JpaRepository<Auction, Integer> {
    public List<Auction> findByStartDateBeforeAndEndDateAfterAndStatus(Date startDate, Date endDate, String status);

    Auction findByInventoryId(Integer inventoryId);
}
