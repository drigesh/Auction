package com.oyo.auctionplatform.controller;

import com.oyo.auctionplatform.entity.Inventory;
import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.pojo.InventoryWithUserDetails;
import com.oyo.auctionplatform.services.InventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

@RestController
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    //Getting all inventories
    @GetMapping("/inventory")
    public List<Inventory> getAllInventories() {
        List<Inventory> inventories = inventoryService.getAllInventories();
        return inventories;

    }

    //Getting inventories by id
    @GetMapping("/inventory/{id}")
    public Inventory getInventoryById(@PathVariable(value = "id") Integer Id)
            throws ResourceNotFoundException {
        return inventoryService.getInventoryById(Id);
    }

    //Inserting a new inventory
    @PostMapping("/inventory")
    public Inventory createInventory(@Valid @RequestBody InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {

        return inventoryService.createInventory(inventoryWithUserDetails);

    }

    //updating an existing inventory
    @PostMapping("/inventory/{id}")
    public Inventory updateInventory(@PathVariable(value = "id") Integer Id,
                                     @Valid @RequestBody InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {
        return inventoryService.updateInventory(Id, inventoryWithUserDetails);
    }

    //check if it is not active and then delete
    //Deleting an existing inventory
    @DeleteMapping("/inventory/{id}")
    public Map<String, Boolean> deleteInventory(@PathVariable(value = "id") Integer Id,
                                                @RequestBody InventoryWithUserDetails inventoryWithUserDetails)
            throws ResourceNotFoundException {

        return inventoryService.deleteInventory(Id, inventoryWithUserDetails);
    }


    //Announcing winner and settling account
    @GetMapping("/inventory/winner/{id}")
    public User getWinnerAndSettleAmount(@PathVariable(value = "id") Integer id) throws ResourceNotFoundException {
        return inventoryService.getWinnerAndSettleAmount(id);
    }


}
