package com.oyo.auctionplatform.repository;

import com.oyo.auctionplatform.entity.Bid;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public interface BidRepo extends JpaRepository<Bid, Integer> {
    //Bid findFirstByAuctionIdOrderByBidPriceDesc(int auction_id);

    Bid findFirstByInventoryIdOrderByBidPriceDesc(int inventoryId);

    ArrayList<Bid> findByInventoryId(int auction_id);

    List<Bid> findByUserId(int userId);
}
