package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.entity.Wallet;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.WalletManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class WalletService {
    @Autowired
    private WalletManager walletManager;



    public Wallet createWallet(User user)
    throws ResourceNotFoundException{
        Wallet wallet = new Wallet( 0, 0, user);
        return walletManager.saveWallet(wallet);
    }


    //Getting wallet by id

    public Wallet getWalletByUserId(Integer userId)
            throws ResourceNotFoundException {
        Wallet wallet = walletManager.getWalletById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found:: " + userId));
        return wallet;
    }

    // Save wallet
    public Wallet saveWallet(Wallet wallet) {
        return walletManager.saveWallet(wallet);
    }



    //Updating wallet by id
//    public Wallet updateWallet(Integer userId, Wallet walletDetails)
//            throws ResourceNotFoundException {
//        Wallet wallet = walletManager.getWalletById(userId)
//                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found :: " + userId));
//
//        wallet.setTotalAmount(walletDetails.getTotalAmount());
//        wallet.setBlockedAmount(walletDetails.getBlockedAmount());
//        final Wallet updateWallet = walletManager.saveWallet(wallet);
//        return updateWallet;
//    }

    //Recharge Wallet

    public Wallet rechargeWallet(Integer userId, float rechargeAmount)
            throws ResourceNotFoundException {
        Wallet wallet = walletManager.getWalletById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found :: " + userId));

        wallet.setTotalAmount(wallet.getTotalAmount() + rechargeAmount);
        return walletManager.saveWallet(wallet);
    }


    //Redeem Money

    public Wallet redeemMoney(Integer userId, float redeemAmount)
            throws ResourceNotFoundException {
        Wallet wallet = walletManager.getWalletById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Wallet not found :: " + userId));
        if (redeemAmount > (wallet.getTotalAmount() - wallet.getBlockedAmount()) || redeemAmount <= 0)
            throw new ResourceNotFoundException("You can only redeem the unblocked amount");
        wallet.setTotalAmount(wallet.getTotalAmount() - redeemAmount);
        return walletManager.saveWallet(wallet);
    }

}
