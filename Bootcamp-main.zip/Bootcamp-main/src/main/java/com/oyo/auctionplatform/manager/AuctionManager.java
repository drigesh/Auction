package com.oyo.auctionplatform.manager;

import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.repository.AuctionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service("AuctionManager")
public class AuctionManager {

    @Autowired
    private AuctionRepo auctionRepo;

    public List<Auction> getAllAuctions() {
        return auctionRepo.findAll();
    }

    public List<Auction> findByStartDateBeforeAndEndDateAfterAndStatus(Date startDate, Date endDate, String status) {
        return auctionRepo.findByStartDateBeforeAndEndDateAfterAndStatus(startDate, endDate, status);
    }

    public Optional<Auction> findByAuctionId(Integer auctionId) {
        return auctionRepo.findById(auctionId);
    }

    public Auction findByInventoryId(Integer inventoryId) throws ResourceNotFoundException {
        Auction auctionByInventory = auctionRepo.findByInventoryId(inventoryId);
        if (auctionByInventory != null)
            return auctionByInventory;
        else
            throw new ResourceNotFoundException("no auction for this inventory is present");
    }

    public Auction saveAuction(Auction auction) {
        return auctionRepo.save(auction);
    }

    public void deleteAuction(Auction auction) {
        auctionRepo.delete(auction);
    }
}
