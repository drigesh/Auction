package com.oyo.auctionplatform.entity;

import com.oyo.auctionplatform.pojo.InventoryMetaData;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.*;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "inventory")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@TypeDefs({
        @TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
})

public class Inventory {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "inventoryId", nullable = false)
    private Integer inventoryId;

    @Column(name = "userId", nullable = false)
    private Integer userId;

    @Column(name = "inventoryName", nullable = false)
    private String inventoryName;

    @Column(name = "arrivalDate", nullable = false)
    private Date arrivalDate;

    @Column(name = "departureDate", nullable = false)
    private Date departureDate;

    @Column(name = "basePrice", nullable = false)
    private float basePrice;

    @ManyToOne(cascade = CascadeType.REMOVE)
    @OnDelete(action = OnDeleteAction.CASCADE)
    @JoinColumn(name = "userId", referencedColumnName = "userId", updatable = false, insertable = false)
    private User user;


    @Column(name = "commission", nullable = false)
    private float commission;

    @Type(type = "jsonb")
    @Column(name = "inventoryMetaData", columnDefinition = "jsonb")
    private InventoryMetaData inventoryMetaData;


}












