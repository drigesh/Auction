package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.Auction;
import com.oyo.auctionplatform.entity.Inventory;
import com.oyo.auctionplatform.entity.User;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.AuctionManager;
import com.oyo.auctionplatform.pojo.AuctionMetaData;
import com.oyo.auctionplatform.pojo.InventoryMetaData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;


class AuctionServiceTest {

    Date date = new Date();
    @Mock
    private BidService bidService;
    @Mock
    private UserService userService;
    @Mock
    private InventoryService inventoryService;
    @Mock
    private WalletService walletService;
    @Mock
    private AuctionManager auctionManager;
    @InjectMocks
    private AuctionService auctionService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test_activeAuctions() throws ResourceNotFoundException {
        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Auction auction1 = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        when(auctionManager.findByStartDateBeforeAndEndDateAfterAndStatus(any(), any(), any())).thenReturn(Stream.of(auction, auction1).collect(Collectors.toList()));
        auctionService.activeAuctions();
    }

}