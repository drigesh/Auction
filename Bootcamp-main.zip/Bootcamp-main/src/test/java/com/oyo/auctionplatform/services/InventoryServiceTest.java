package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.*;
import com.oyo.auctionplatform.manager.InventoryManager;
import com.oyo.auctionplatform.pojo.AuctionMetaData;
import com.oyo.auctionplatform.pojo.InventoryMetaData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Date;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class InventoryServiceTest {

    Date date = new Date();
    InventoryMetaData inventoryMetaData;
    @Mock
    private BidService bidService;
    @Mock
    private UserService userService;
    @Mock
    private AuctionService auctionService;
    @Mock
    private WalletService walletService;
    @Mock
    private InventoryManager inventoryManager;
    @InjectMocks
    private InventoryService inventoryService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    public void test_getWinnerOfInventory_scenario_result() throws Exception {
        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Wallet wallet = new Wallet(1, 30000, user);

        Bid bid = new Bid(1, 1, 1, 20000, date, user, inventory);


        when(userService.getUserById(any())).thenReturn(user);
        when(inventoryManager.getInventoryById(any())).thenReturn(Optional.of(inventory));
        when(auctionService.getAuctionByInventoryId(any())).thenReturn(auction);
        when(walletService.getWalletByUserId(any())).thenReturn(wallet);
        when(bidService.getHighestBid(any())).thenReturn(bid);

        inventoryService.getWinnerAndSettleAmount(1);
    }


}
