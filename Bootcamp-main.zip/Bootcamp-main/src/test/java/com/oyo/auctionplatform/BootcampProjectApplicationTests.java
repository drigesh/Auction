//package com.oyo.auctionplatform;
//
//import com.oyo.auctionplatform.entity.Auction;
//import com.oyo.auctionplatform.entity.Bid;
//import com.oyo.auctionplatform.entity.Inventory;
//import com.oyo.auctionplatform.entity.User;
//import com.oyo.auctionplatform.services.AuctionService;
//import com.oyo.auctionplatform.services.BidService;
//import com.oyo.auctionplatform.services.UserService;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import java.util.Date;
//
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.Mockito.when;
//
////@RunWith(MockitoJUnitRunner.class)
////@SpringBootTest
////@ActiveProfiles("default")
//public class BootcampProjectApplicationTests {
//
//    @Mock
//    private BidService bidService;
//
//
//    @Mock
//    private UserService userService;
//
////	@Mock
////	private BidRepo bidRepo;
//
//    @InjectMocks
//    private AuctionService auctionService;
//
//    Date date = new Date();
//
//
//    @BeforeEach
//    public void init() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    @Test
//    public void test_getWinnerOfAuction_scenario_result() throws Exception {
//        User user = new User(1, "name", "name@oyo.com", "password", "1234567890", "address", 1);
//        Inventory inventory = new Inventory(1, 1, 110044, "name", "state", "address", "country", "1234567890", new Date(), new Date(), 25);
//        Auction auction = new Auction(1, "active", new Date(), new Date(), 12000, 500, 20000, inventory);
//        Bid bid = new Bid(1, 1, 1, 20000, date, user, auction);
//
//        when(bidService.getHighestBid(anyInt())).thenReturn(new Bid(1, 1, 1, 20000, date, user, auction));
//        when(userService.getUserById(1)).thenReturn(user);
//
//        auctionService.getWinnerOfAuction(1);
//    }
//
//
//}
