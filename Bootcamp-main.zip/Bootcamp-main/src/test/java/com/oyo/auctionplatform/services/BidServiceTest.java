package com.oyo.auctionplatform.services;

import com.oyo.auctionplatform.entity.*;
import com.oyo.auctionplatform.exception.ResourceNotFoundException;
import com.oyo.auctionplatform.manager.BidManager;
import com.oyo.auctionplatform.pojo.AuctionMetaData;
import com.oyo.auctionplatform.pojo.InventoryMetaData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class BidServiceTest {


    @Mock
    BidManager bidManager;
    @Mock
    InventoryService inventoryService;

    @Mock
    AuctionService auctionService;

    @Mock
    WalletService walletService;

    @InjectMocks
    BidService bidService;


    Date date = new Date();


    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void test_getHighestBid() throws ResourceNotFoundException {

        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Bid bid = new Bid(1, 1, 1, 20000, date, user, inventory);
        Bid bid1 = new Bid(2, 1, 1, 25000, date, user, inventory);


        when(bidManager.getBidsByInventoryId(1)).thenReturn((ArrayList<Bid>) Stream
                .of(bid, bid1).collect(Collectors.toList()));

        when(bidManager.getFirstByInventoryIdOrderByBidPriceDesc(1)).thenReturn(bid);

        Bid response = bidService.getHighestBid(1);
        assertNotNull(response);


    }


    @Test
    public void test_addBid_validBid_placeBid() throws ResourceNotFoundException {

        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Wallet wallet = new Wallet(1, 30000, user);

        Bid bid = new Bid(1, 1, 1, 20000, date, user, inventory);
        Bid bid1 = new Bid(2, 1, 1, 25000, date, user, inventory);

        when(inventoryService.getInventoryById(any())).thenReturn(inventory);
        when(auctionService.getAuctionByInventoryId(1)).thenReturn(auction);
        when(bidManager.getBidsByInventoryId(1)).thenReturn((ArrayList<Bid>) Stream
                .of(bid, bid1).collect(Collectors.toList()));
        when(walletService.getWalletByUserId(any())).thenReturn(wallet);
        when(bidManager.getFirstByInventoryIdOrderByBidPriceDesc(1)).thenReturn(bid);


        when(bidManager.saveBid(any())).thenReturn((bid));
        Bid response = bidService.createBid(bid1);
        assertNotNull(response);
    }


    @Test
    public void test_addBid_bidLessThanHighest_bidNotPlaced() throws ResourceNotFoundException {

        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "active", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Wallet wallet = new Wallet(1, 30000, user);

        Bid bid1 = new Bid(1, 1, 1, 20000, date, user, inventory);
        Bid bid = new Bid(2, 1, 1, 25000, date, user, inventory);

        when(inventoryService.getInventoryById(any())).thenReturn(inventory);
        when(auctionService.getAuctionByInventoryId(1)).thenReturn(auction);
        when(bidManager.getBidsByInventoryId(1)).thenReturn((ArrayList<Bid>) Stream
                .of(bid, bid1).collect(Collectors.toList()));
        when(walletService.getWalletByUserId(any())).thenReturn(wallet);
        when(bidManager.getFirstByInventoryIdOrderByBidPriceDesc(1)).thenReturn(bid);


        when(bidManager.saveBid(any())).thenReturn((bid));
        //Bid response = bidService.createBid(bid1);
        //System.out.println(response);
        //assertNotNull(response);

        try {
            Bid response = bidService.createBid(bid1);

        } catch (ResourceNotFoundException resourceNotFoundException) {
            assertEquals("auction cant be placed because it is not in suggested limit", resourceNotFoundException.getMessage());
        }
    }


    @Test
    public void test_addBid_auctionNotActive_bidNotPlaced() throws ResourceNotFoundException {

        User user = new User("name", 1, "name@oyo.com", "password",
                "1234567890", "address", 1);
        Inventory inventory = new Inventory(1, 1, 1, "name", new Date(),
                new Date(), 12000, user, 20, new InventoryMetaData());

        Auction auction = new Auction(1, 1, "inactive", new Date(), new Date(), 500,
                30000, 1, inventory, new AuctionMetaData());

        Wallet wallet = new Wallet(1, 30000, user);

        Bid bid1 = new Bid(1, 1, 1, 20000, date, user, inventory);
        Bid bid = new Bid(2, 1, 1, 25000, date, user, inventory);

        when(inventoryService.getInventoryById(any())).thenReturn(inventory);
        when(auctionService.getAuctionByInventoryId(1)).thenReturn(auction);
        when(bidManager.getBidsByInventoryId(1)).thenReturn((ArrayList<Bid>) Stream
                .of(bid, bid1).collect(Collectors.toList()));
        when(walletService.getWalletByUserId(any())).thenReturn(wallet);
        when(bidManager.getFirstByInventoryIdOrderByBidPriceDesc(1)).thenReturn(bid);
        //when(ResourceNotFoundException)


        when(bidManager.saveBid(any())).thenReturn((bid));
        try {
            Bid response = bidService.createBid(bid1);

        } catch (ResourceNotFoundException resourceNotFoundException) {
            assertEquals("this Auction is over now", resourceNotFoundException.getMessage());
        }
        //assertNotNull(response);
//        assertEquals(response,new ResourceNotFoundException("this Auction is over now"));
    }

}
